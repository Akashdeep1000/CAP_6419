function M = met_rect(file_name)
im = imread(file_name);
imshow(im)
[x,y]= ginput(4);
p1 = [x(1) y(1)];
p3 = [x(3) y(3)];
p2 = [x(2) y(2)];
p4 = [x(4) y(4)];

%This is what the equation is after computing the orthonormal points
G = [p1(1)*p2(1) (p1(1)*p2(2)+p1(2)*p2(1)) ; p3(1)*p4(1) (p3(1)*p4(2)+p3(2)*p4(1))];
A = [-p1(2)*p2(2);-p3(2)*p4(2)];
X = G \ A;
S = [X(1) X(2); X(2) 1];
[U,D,V] = svd(S);

A = U*sqrt(D)*V';
H = eye(3);
H(1:2, 1:2) = A;


outim = TransformImage(im,H); %
imshow(outim);
imwrite(outim, "UCFSU_met.jpg")
end