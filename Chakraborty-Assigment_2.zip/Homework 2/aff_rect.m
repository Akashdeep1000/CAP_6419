function X = aff_rect(img_name)
% read the input image
img = imread(img_name);
figure(1)
imshow(img)
title('Select four points for parallel lines')
[x,y] = ginput(4);
close Figure 1
% points from image; manual selection
point1 = [x(1) y(1) 1]; 
point2 = [x(2) y(2) 1];
point3 = [x(3) y(3) 1]; 
point4 = [x(4) y(4) 1];
% lines by cross product of points
line1 = cross(point1,point2); 
line2 = cross(point3,point4);
line3 = cross(point1, point3); 
line4 = cross(point2, point4);
% point at infinity
inf_1 = cross(line1, line2); 
inf_1 = inf_1/inf_1(1,3);
inf_2 = cross(line3, line4); 
inf_2 = inf_2/ inf_2(1,3); 

% now line at infinity
line_inf = cross(inf_1, inf_2); 
line_inf_1 = line_inf(1, 1)/line_inf(1,3);
line_inf_2 = line_inf(1, 2)/line_inf(1,3);

% transformation matrix X
X = [1 0 0; 0 1 0; line_inf_1 line_inf_2 1];

out_img = TransformImage(img, X);
% show rectified image
figure(2);
imshow(out_img)
imwrite(out_img,"affine_rectified/"+ img_name +"_aff.jpg" )
end


