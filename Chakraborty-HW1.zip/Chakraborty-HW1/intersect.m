function intersect()
    %Taking the a, d, e, f as the input values as b =0 and c=a

    prompt = "input a = ";
    a =input(prompt);
        prompt = "input d = ";
    d =input(prompt);
        prompt = "input e = ";
    e =input(prompt);
        prompt = "input f = ";
    f =input(prompt);

    c=a;

    b=0;
    %Matrix C is created
    C =[a b d; b c e; d e f];
    % Intitalized m1 and m2 with arbitrary points
    m1 = [2; 3; 0];
    m2 = [3; 4; 0];
    %taking 
    x = roots([m2' * C * m2,  2*m2' * C * m1,  m1' * C * m1]);

    y1 = m1+x(1,1)*m2
    y2 = m1+x(2,1)*m2
   
    
end